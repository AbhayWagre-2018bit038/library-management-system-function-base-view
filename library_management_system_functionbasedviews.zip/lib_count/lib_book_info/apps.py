from django.apps import AppConfig


class LibBookInfoConfig(AppConfig):
    name = 'lib_book_info'
