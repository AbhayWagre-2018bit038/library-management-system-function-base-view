from django.db import models

# Create your models here.
class book_add(models.Model):
    book_name=models.CharField(max_length=300)
    book_auhtor_name=models.CharField(max_length=300)
    book_edition=models.PositiveIntegerField(max_length=300)

    def __str__(self):
        return '%s -- %s'% (self.book_name,self.book_auhtor_name)

class student_info(models.Model):
    stud_name=models.CharField( max_length=300)
    stud_mob=models.BigIntegerField()
    stud_roll=models.PositiveIntegerField()
    stud_add=models.TextField()
    stud_class=models.PositiveIntegerField()

    def __str__(self):
        return '%s -- %d -- %d'% (self.stud_name,self.stud_class,self.stud_roll)

class employee_info(models.Model):
    empl_name=models.CharField(max_length=300)
    empl_mob=models.BigIntegerField()
    empl_add=models.TextField()
    empl_job=models.CharField(max_length=300)
    empl_join_date=models.DateField()

    def __str__(self):
        return '%s -- %s'% (self.empl_name,self.empl_job)

class borrow_book(models.Model):
    stud_name=models.ForeignKey(student_info,on_delete=models.CASCADE)
    book_name=models.ForeignKey(book_add,on_delete=models.CASCADE)
    Issue_date=models.DateField()

    

    