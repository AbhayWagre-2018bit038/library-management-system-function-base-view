from django.contrib import admin
from .models import *
# Register your models here.
class book_addAdmin(admin.ModelAdmin):
    list_display=['book_name','book_auhtor_name','book_edition']
    search_fields=('book_name','book_auhtor_name')
admin.site.register(book_add,book_addAdmin)  

class student_infoAdmin(admin.ModelAdmin):
    list_display=['stud_name','stud_roll','stud_class','stud_add']
    search_fields=('stud_name','stud_roll','stud_class')
admin.site.register(student_info,student_infoAdmin)  

class employee_infoAdmin(admin.ModelAdmin):
    list_display=['empl_name','empl_mob','empl_add','empl_join_date']
    search_fields=('empl_name','empl_job')
admin.site.register(employee_info,employee_infoAdmin)

class borrow_bookAdmin(admin.ModelAdmin):
    list_display=['stud_name','book_name','Issue_date']
    search_fields=('stud_name','book_name')
admin.site.register(borrow_book,borrow_bookAdmin)