from django.shortcuts import render
from .models import *
from django.http import HttpResponse


# Create your views here.
def recorder(request):
    all_student=student_info.objects.all()
    all_book=book_add.objects.all()
    all_borrow_book=borrow_book.objects.all()
    return render(request,'all_display.html',{"all_student":all_student,"all_book":all_book,"all_borrow_book":all_borrow_book})

def individual_post(request):
    all_employee=employee_info.objects.all()
    return render(request,'emplyee_diplay.html',{"all_employee":all_employee})

